﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogInForm
{
    public partial class customerForm : Form
    {
        public SqlConnection sqlCon;
        public SqlCommand cmd;
        public SqlDataAdapter dataAdapter;
        public SqlDataReader dataReader;
        private string connection = "Data Source=.\\sqlexpress;Initial Catalog=syomai;Integrated Security=True;";
        static bool sidebarExpand;

        private PictureBox product;
        private Label productName;
        private Label ofStock;
        private Label productPrice;

        private int userId;
        public customerForm(int userId)
        {
            InitializeComponent();
            sqlCon = new SqlConnection(connection);

            this.userId = userId;
        }

        private void customerForm_Load(object sender, EventArgs e)
        {
            loadData();

            receipt.Columns["OrderName"].DataPropertyName = "P_NAME";
            receipt.Columns["OrderPrice"].DataPropertyName = "P_PRICE";
        }

        private void loadData()
        {
            try
            {
                sqlCon.Open();
                string query = "SELECT P_IMAGE, P_NAME, P_PRICE, P_QUANTITY, PID FROM PRODUCTS ";
                cmd = new SqlCommand(query, sqlCon);
                dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    receipt.ColumnHeadersVisible = false;

                    long len = dataReader.GetBytes(0, 0, null, 0, 0);
                    byte[] array = new byte[System.Convert.ToInt32(len) + 1];
                    dataReader.GetBytes(0, 0, array, 0, System.Convert.ToInt32(len));
                    product = new PictureBox();
                    product.Width = 162;
                    product.Height = 170;
                    product.BackgroundImageLayout = ImageLayout.Zoom;
                    product.BorderStyle = BorderStyle.FixedSingle;
                    product.BackColor = Color.FromArgb(140, 158, 189);
                    product.Cursor = Cursors.Hand;
                    string productId = dataReader["PID"].ToString();
                    product.Tag = productId;

                    productPrice = new Label();
                    double price = Convert.ToDouble(dataReader["P_PRICE"]);
                    string formattedPrice = String.Format("{0:0.00}", price);
                    productPrice.Text = formattedPrice;
                    productPrice.BackColor = Color.FromArgb(35, 40, 45);
                    productPrice.ForeColor = Color.White;
                    productPrice.Width = 70;
                    productPrice.TextAlign = ContentAlignment.MiddleCenter;
                    productPrice.Font = new Font("Cooper Black", 11, FontStyle.Regular);

                    productName = new Label();
                    productName.Text = dataReader["P_NAME"].ToString();
                    productName.BackColor = Color.FromArgb(35, 40, 45);
                    productName.ForeColor = Color.White;
                    productName.Dock = DockStyle.Bottom;
                    productName.Height = 30;
                    productName.Font = new Font("Cooper Black", 12, FontStyle.Regular);
                    productName.TextAlign = ContentAlignment.MiddleCenter;
                    productName.Padding = new Padding(0, 5, 0, 0);

                    MemoryStream ms = new MemoryStream(array);
                    System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(ms);
                    product.BackgroundImage = bitmap;

                    product.Controls.Add(productPrice);
                    product.Controls.Add(productName);
                    orderbox.Controls.Add(product);

                    product.Click += new EventHandler(OnClick);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
            finally
            {
                if (dataReader != null)
                    dataReader.Close();
                if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }


        private void OnClick(object sender, EventArgs e)
        {
            string tag = ((PictureBox)sender).Tag.ToString();
            string productName = "";
            double productPrice = 0.0;
            double unitPrice = 0.0;
            int availableQuantity = 0;
            char add = '+';
            char remove = '-';
            try
            {
                // Make sure to close any pending transaction before opening the connection
                if (sqlCon.State == ConnectionState.Open)
                {
                    sqlCon.Close();
                }

                sqlCon.Open();
                string query = "SELECT P_NAME, P_PRICE, P_QUANTITY FROM PRODUCTS WHERE PID LIKE @Tag";
                using (SqlCommand cmd = new SqlCommand(query, sqlCon))
                {
                    cmd.Parameters.AddWithValue("@Tag", tag);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            productName = reader["P_NAME"].ToString();
                            availableQuantity = Convert.ToInt32(reader["P_QUANTITY"]);
                            unitPrice = Convert.ToDouble(reader["P_PRICE"]);
                            productPrice = Convert.ToDouble(reader["P_PRICE"]);
                        }
                    }
                }

                bool productFound = false;
                foreach (DataGridViewRow row in receipt.Rows)
                {
                    if (row.Cells["OrderName"].Value.ToString() == productName)
                    {
                        productFound = true;
                        int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                        if (quantity < availableQuantity)
                        {
                            row.Cells["OrderQuantity"].Value = quantity + 1; // Increase quantity
                            row.Cells["OrderPrice"].Value = (quantity + 1) * unitPrice; // Update price
                        }
                        else
                        {
                            MessageBox.Show("Maximum quantity reached for this product.");
                        }
                        break;
                    }
                }

                if (!productFound && availableQuantity > 0)
                {
                    receipt.Rows.Add(receipt.Rows.Count + 1, tag, productName, 1, unitPrice.ToString("#,##0.00"), productPrice.ToString("#,##0.00"), remove, add);
                }
                else if (availableQuantity <= 0)
                {
                    MessageBox.Show("Product is out of stock.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }

        private byte[] GetProductImageBytes(int productId)
        {
            byte[] imageData = null;

            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    string query = "SELECT P_IMAGE FROM PRODUCTS WHERE PID = @ProductId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@ProductId", productId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        if (!reader.IsDBNull(0))
                        {
                            // Retrieve image data
                            imageData = (byte[])reader["P_IMAGE"];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show("Error retrieving  image: " + ex.Message);
            }

            return imageData;
        }
        private string getCustName(int custId)
        {
            string custName = "";

            try
            {
                using (SqlConnection con = new SqlConnection(connection))
                {
                    con.Open();
                    string query = "SELECT C_Firstname FROM CUSTOMERS WHERE CID = @CID";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@CID", custId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        if (!reader.IsDBNull(0))
                        {
                            // Retrieve the customer name
                            custName = reader.GetString(0);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show("Error retrieving customer name: " + ex.Message);
            }

            return custName;
        }


        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            SqlTransaction transaction = null;
            try
            {
                sqlCon.Open();
                transaction = sqlCon.BeginTransaction();

                foreach (DataGridViewRow row in receipt.Rows)
                {
                    int productId = Convert.ToInt32(row.Cells["OID"].Value);
                    int quantity = Convert.ToInt32(row.Cells["OrderQuantity"].Value);
                    double productPrice = Convert.ToDouble(row.Cells["UnitPrice"].Value);
                    string productName = row.Cells["OrderName"].Value.ToString();


                    string customerName = getCustName(userId);
                    // Assuming you have the image data available in a variable named productImageBytes
                    byte[] productImageBytes = GetProductImageBytes(productId); // You need to implement this method to get image data

                    string insertQuery = "INSERT INTO ORDERS (PRODUCT_ID, PRODUCT_NAME, PRODUCT_IMAGE, CUSTOMER_ID, CUSTOMER_NAME, ORDERED_QUANTITY, PRODUCT_PRICE, ORDER_TOTAL_PRICE, ORDER_DATE) " +
                                         "VALUES (@ProductId, @ProductName, @ProductImage, @userId, @CustomerName, @Quantity, @ProductPrice, @TotalPrice, GETDATE())";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, sqlCon, transaction);
                    insertCmd.Parameters.AddWithValue("@ProductId", productId);
                    insertCmd.Parameters.AddWithValue("@ProductName", productName);
                    insertCmd.Parameters.AddWithValue("@ProductImage", productImageBytes);
                    insertCmd.Parameters.AddWithValue("@CustomerName", customerName);
                    insertCmd.Parameters.AddWithValue("@userId", userId);
                    insertCmd.Parameters.AddWithValue("@Quantity", quantity);
                    insertCmd.Parameters.AddWithValue("@ProductPrice", productPrice);
                    insertCmd.Parameters.AddWithValue("@TotalPrice", productPrice * quantity);
                    insertCmd.ExecuteNonQuery();

                    UpdateProductStock(productId, quantity);
                }

                transaction.Commit();
                MessageBox.Show("Order placed successfully!");
                receipt.Rows.Clear();
            }
            catch (Exception ex)
            {
                if (transaction != null)
                    transaction.Rollback();
                MessageBox.Show("Error placing order: " + ex.Message);
            }
            finally
            {
                if (sqlCon.State == ConnectionState.Open)
                    sqlCon.Close();
            }
        }


        private void UpdateProductStock(int productId, int purchasedQuantity)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=syomai;Integrated Security=True;"))
                {
                    connection.Open();

                    // Begin transaction
                    using (SqlTransaction transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Retrieve the current stock quantity of the product
                            string selectQuery = "SELECT P_QUANTITY FROM PRODUCTS WHERE PID = @ProductId";
                            SqlCommand selectCmd = new SqlCommand(selectQuery, connection, transaction);
                            selectCmd.Parameters.AddWithValue("@ProductId", productId);

                            // Execute the command to retrieve the current stock quantity
                            int currentStock = Convert.ToInt32(selectCmd.ExecuteScalar());

                            // Calculate the new stock quantity after the purchase
                            int newStock = currentStock - purchasedQuantity;

                            if (newStock < 0)
                            {
                                MessageBox.Show("Insufficient stock.");
                                return;
                            }

                            // Update the database with the new stock quantity
                            string updateQuery = "UPDATE PRODUCTS SET P_QUANTITY = @NewStock WHERE PID = @ProductId";
                            SqlCommand updateCmd = new SqlCommand(updateQuery, connection, transaction);
                            updateCmd.Parameters.AddWithValue("@NewStock", newStock);
                            updateCmd.Parameters.AddWithValue("@ProductId", productId);
                            updateCmd.ExecuteNonQuery();

                            // Commit the transaction
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            // Rollback the transaction in case of any error
                            transaction.Rollback();
                            MessageBox.Show("Error updating product stock: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void receipt_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex >= 0 && receipt.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                int rowIndex = e.RowIndex;

                if (e.ColumnIndex == receipt.Columns.Count - 1)
                {
                    int currentQuantity = Convert.ToInt32(receipt.Rows[rowIndex].Cells["OrderQuantity"].Value);
                    receipt.Rows[rowIndex].Cells["OrderQuantity"].Value = currentQuantity + 1;
                }
                else if (e.ColumnIndex == receipt.Columns.Count - 2)
                {
                    int currentQuantity = Convert.ToInt32(receipt.Rows[rowIndex].Cells["OrderQuantity"].Value);
                    if (currentQuantity > 1)
                    {
                        receipt.Rows[rowIndex].Cells["OrderQuantity"].Value = currentQuantity - 1;
                    }
                    else
                    {
                        receipt.Rows.RemoveAt(rowIndex);

                        for (int i = rowIndex; i < receipt.Rows.Count; i++)
                        {
                            receipt.Rows[i].Cells["OrderNo"].Value = (i + 1).ToString();
                        }
                    }
                }
            }
        }

        private void receipt_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == receipt.Columns["OrderQuantity"].Index)
            {
                int rowIndex = e.RowIndex;
                int quantity = Convert.ToInt32(receipt.Rows[rowIndex].Cells["OrderQuantity"].Value);
                double unitPrice = Convert.ToDouble(receipt.Rows[rowIndex].Cells["UnitPrice"].Value);

                if (quantity == 0)
                {
                    receipt.Rows.RemoveAt(rowIndex);
                }
                else
                {
                    double totalPrice = quantity * unitPrice;
                    receipt.Rows[rowIndex].Cells["OrderPrice"].Value = totalPrice.ToString("#,##0.00");
                }
            }
        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                sidebar.Width -= 10;
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            else
            {
                sidebar.Width += 10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {
            panelAccount.Enabled = true;
            panelAccount.Visible = true;
            loadUserData();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
        }

        private void closeEditAcc_Click(object sender, EventArgs e)
        {
            panelAccount.Enabled = false;
            panelAccount.Visible = false;
            txtBoxFName.Enabled = false;
            txtBoxLName.Enabled = false;
            txtBoxAge.Enabled = false;
            txtBoxEmail.Enabled = false;
            txtBoxAddress.Enabled = false;
            txtBoxUsername.Enabled = false;
            txtBoxFName.BorderStyle = BorderStyle.None;
            txtBoxLName.BorderStyle = BorderStyle.None;
            txtBoxAge.BorderStyle = BorderStyle.None;
            txtBoxEmail.BorderStyle = BorderStyle.None;
            txtBoxAddress.BorderStyle = BorderStyle.None;
            txtBoxUsername.BorderStyle = BorderStyle.None;
            btnSaveAcc.Enabled = false;
        }

        private void loadUserData()
        {
            int id = userId;

            string query = "SELECT C_Firstname, C_Lastname, C_Age, C_Email, C_Address, C_Username FROM CUSTOMERS WHERE CID = @id";

            using (SqlCommand cmd = new SqlCommand(query, sqlCon))
            {
                cmd.Parameters.AddWithValue("@id", id);

                try
                {
                    sqlCon.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        // Populate text boxes with user data
                        if (string.IsNullOrWhiteSpace(txtBoxFName.Text))
                        {
                            txtBoxFName.Text = reader["C_Firstname"].ToString();
                        }
                        if (string.IsNullOrWhiteSpace(txtBoxLName.Text))
                        {
                            txtBoxLName.Text = reader["C_Lastname"].ToString();
                        }
                        if (string.IsNullOrWhiteSpace(txtBoxAge.Text))
                        {
                            txtBoxAge.Text = reader["C_Age"].ToString();
                        }
                        if (string.IsNullOrWhiteSpace(txtBoxEmail.Text))
                        {
                            txtBoxEmail.Text = reader["C_Email"].ToString();
                        }
                        if (string.IsNullOrWhiteSpace(txtBoxAddress.Text))
                        {
                            txtBoxAddress.Text = reader["C_Address"].ToString();
                        }
                        if (string.IsNullOrWhiteSpace(txtBoxUsername.Text))
                        {
                            txtBoxUsername.Text = reader["C_Username"].ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("User not found");
                    }
                    reader.Close();
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show("SQL Error: " + sqlEx.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        private void btnEditAcc_Click(object sender, EventArgs e)
        {
            txtBoxFName.Enabled = true;
            txtBoxLName.Enabled = true;
            txtBoxAge.Enabled = true;
            txtBoxEmail.Enabled = true;
            txtBoxAddress.Enabled = true;
            txtBoxUsername.Enabled = true;
            txtBoxFName.BorderStyle = BorderStyle.FixedSingle;
            txtBoxLName.BorderStyle = BorderStyle.FixedSingle;
            txtBoxAge.BorderStyle = BorderStyle.FixedSingle;
            txtBoxEmail.BorderStyle = BorderStyle.FixedSingle;
            txtBoxAddress.BorderStyle = BorderStyle.FixedSingle;
            txtBoxUsername.BorderStyle = BorderStyle.FixedSingle;
            btnSaveAcc.Enabled = true;
            btnCancel.Enabled = true;
            btnCancel.Visible = true;

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.ShowDialog();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtBoxFName.Enabled = false;
            txtBoxLName.Enabled = false;
            txtBoxAge.Enabled = false;
            txtBoxEmail.Enabled = false;
            txtBoxAddress.Enabled = false;
            txtBoxUsername.Enabled = false;
            txtBoxFName.BorderStyle = BorderStyle.None;
            txtBoxLName.BorderStyle = BorderStyle.None;
            txtBoxAge.BorderStyle = BorderStyle.None;
            txtBoxEmail.BorderStyle = BorderStyle.None;
            txtBoxAddress.BorderStyle = BorderStyle.None;
            txtBoxUsername.BorderStyle = BorderStyle.None;
            btnSaveAcc.Enabled = false;
            btnCancel.Enabled = false;
            btnCancel.Visible = false;
        }

        private bool ValidateFields()
        {
            // Error handling for firstname, lastname, and address
            if (!string.IsNullOrWhiteSpace(txtBoxFName.Text) && !IsLettersOnly(txtBoxFName.Text))
            {
                MessageBox.Show("Firstname should contain only letters.");
                txtBoxFName.Text = "";
                return false;
            }
            if (!string.IsNullOrWhiteSpace(txtBoxLName.Text) && !IsLettersOnly(txtBoxLName.Text))
            {
                MessageBox.Show("Lastname should contain only letters.");
                txtBoxLName.Text = "";
                return false;
            }
            if (!string.IsNullOrWhiteSpace(txtBoxAddress.Text) && !IsLettersOnly(txtBoxAddress.Text) && !IsNumeric(txtBoxAddress.Text))
            {
                MessageBox.Show("Address should contain only letters and digits.");
                txtBoxAddress.Text = "";
                return false;
            }
            // Error handling for age (numeric)
            if (!string.IsNullOrWhiteSpace(txtBoxAge.Text) && !IsNumeric(txtBoxAge.Text))
            {
                MessageBox.Show("Age should contain only numeric characters.");
                txtBoxAge.Text = "";
                return false;
            }

            // Validation passed
            return true;
        }

        private bool IsLettersOnly(string text)
        {
            return text.All(char.IsLetter);
        }

        private bool IsNumeric(string text)
        {
            return text.All(char.IsDigit);
        }

        private void btnSaveAcc_Click(object sender, EventArgs e)
        {
            SqlDataReader reader = null;
            SqlCommand command = null;

            try
            {
                sqlCon.Open();
                string selectQuery = "SELECT * FROM CUSTOMERS WHERE CID = @CustomerID";
                command = new SqlCommand(selectQuery, sqlCon);
                command.Parameters.AddWithValue("@CustomerID", userId); // Assuming userId is available
                reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Populate text boxes with user data
                    txtBoxFName.Text = reader["C_Firstname"].ToString();
                    txtBoxLName.Text = reader["C_Lastname"].ToString();
                    txtBoxAge.Text = reader["C_Age"].ToString();
                    txtBoxEmail.Text = reader["C_Email"].ToString();
                    txtBoxAddress.Text = reader["C_Address"].ToString();
                    txtBoxUsername.Text = reader["C_Username"].ToString();

                    // Validate user input
                    if (!ValidateFields())
                    {
                        MessageBox.Show("Please correct the input fields.");
                        return;
                    }

                    // Update user data
                    string updateQuery = @"UPDATE CUSTOMERS 
                                   SET C_Firstname = @Firstname,
                                       C_Lastname = @Lastname,
                                       C_Age = @Age,
                                       C_Email = @Email,
                                       C_Address = @Address,
                                       C_Username = @Username
                                   WHERE CID = @CustomerID";
                    reader.Close(); // Close the reader before executing the update query
                    command = new SqlCommand(updateQuery, sqlCon);
                    command.Parameters.AddWithValue("@CustomerID", userId);
                    command.Parameters.AddWithValue("@Firstname", txtBoxFName.Text);
                    command.Parameters.AddWithValue("@Lastname", txtBoxLName.Text);
                    command.Parameters.AddWithValue("@Age", txtBoxAge.Text);
                    command.Parameters.AddWithValue("@Email", txtBoxEmail.Text);
                    command.Parameters.AddWithValue("@Address", txtBoxAddress.Text);
                    command.Parameters.AddWithValue("@Username", txtBoxUsername.Text);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("User data updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update user data.");
                    }
                }
                else
                {
                    MessageBox.Show("No user found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                // Close the reader and connection
                reader?.Close();
                sqlCon?.Close();
            }
        }
    }
}
