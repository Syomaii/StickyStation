﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace LogInForm
{
    public partial class AdminDashboard : Form
    {
        static bool sidebarExpand;
        static string connection = "Data Source=.\\sqlexpress;Initial Catalog=syomai;Integrated Security=True;";
        SqlConnection con;

        private int userId;
        public AdminDashboard(int userId)
        {
            InitializeComponent();
            
            con = new SqlConnection(connection);
            this.userId = userId;
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            panelView.Visible = false;
            panelView.Enabled = false; 
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Enabled = false;
            panelAddProd.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelProd.Visible = false;
            panelProd.Enabled = false; 
            panelOrders.Enabled = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            logoPic.BringToFront();
            lblAdmin.BringToFront();
            sidebar.BringToFront();
        }

        private void sidebarTimer_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand) 
            {
                sidebar.Width -= 10;
                if(sidebar.Width == sidebar.MinimumSize.Width) 
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            else
            {
                sidebar.Width += 10;
                if (sidebar.Width == sidebar.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    sidebarTimer.Stop();
                }
            }
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {
            sidebarTimer.Start();
        }
                
        private void loadDataGridUsers()
        {
            con.Open();
            SqlCommand com = new SqlCommand("SELECT C_ID AS CustomerID," +
                                "C_Username AS Username," +
                                "C_Firstname AS Firstname," +
                                "C_Lastname AS Lastname," +
                                "C_Age AS Age," +
                                "C_Email AS Email," +
                                "C_Address AS Address," +
                                "C_UserType AS Type " + 
                                "FROM CUSTOMERS", con);

            com.ExecuteNonQuery();

            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable data = new DataTable();
            adapter.Fill(data);
            dgvView.DataSource = data;
            con.Close();
        }

        private void loadDataGridProducts()
        {
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT P_ID AS ProductID, " +
                                       "P_IMAGE AS ProductImage, " +
                                       "P_NAME AS ProductName, " +
                                       "P_QUANTITY AS ProductQuantity, " +
                                       "P_PRICE AS ProductPrice " +
                                 "FROM PRODUCTS", con);
                SqlDataAdapter dataAdapter = new SqlDataAdapter(com);
                DataTable data = new DataTable();
                data.Clear();
                dataAdapter.Fill(data);
                dgvProducts.DataSource = data;
                DataGridViewImageColumn pImage = new DataGridViewImageColumn();
                pImage = (DataGridViewImageColumn)dgvProducts.Columns[1];
                pImage.ImageLayout = DataGridViewImageCellLayout.Zoom;
                /*
                 SqlCommand com = new SqlCommand("SELECT P_ID AS ProductID, " +
                                       "P_IMAGE, " +
                                       "P_NAME AS ProductName, " +
                                       "P_QUANTITY AS ProductQuantity, " +
                                       "P_PRICE AS ProductPrice " +
                                 "FROM PRODUCTS", con);

                SqlDataReader reader = com.ExecuteReader();

                DataTable data = new DataTable();
                data.Load(reader);
                data.Columns.Add("PIMAGE", typeof(byte[]));
                foreach (DataRow row in data.Rows)
                {
                    string imagePath = row["PIMAGE"].ToString();
                    if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                    {
                        row["PIMAGE"] = File.ReadAllBytes(imagePath);
                    }
                }

                dgvProducts.DataSource = data;
                 */
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }



        private void loadDataGridOrders()
        {
            con.Open();
            SqlCommand com = new SqlCommand("SELECT O_ID AS OrderId," +
                    "PRODUCT_ID AS ProductID," +
                    "PRODUCT_NAME AS ProductName," +
                    "PRODUCT_IMAGE AS ProductName," +
                    "ORDERED_QUANTITY AS OrderedQuantity," +
                    "PRODUCT_PRICE AS ProductPrice," +
                    "ORDER_TOTAL_PRICE AS OrderTotalPrice," +
                    "ORDER_DATE AS OrderDate " +
                    "FROM ORDERS", con);


            com.ExecuteNonQuery();

            SqlDataAdapter adapter = new SqlDataAdapter(com);
            DataTable data = new DataTable();
            adapter.Fill(data);
            dgvOrders.DataSource = data;
            DataGridViewImageColumn prodImage = new DataGridViewImageColumn();
            prodImage = (DataGridViewImageColumn)dgvOrders.Columns[3];
            prodImage.ImageLayout = DataGridViewImageCellLayout.Zoom;
            con.Close();
        }



        private void LoadAdminAccounts()
        {
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT A_ID AS AdminID," +
                                                "A_Username AS Username," +
                                                "A_Firstname AS Firstname," +
                                                "A_Lastname AS Lastname," +
                                                "A_Age AS Age," +
                                                "A_Email AS Email," +
                                                "A_Address AS Address," +
                                                "A_UserType AS Type " +
                                                "FROM ADMINISTRATOR", con);

                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable data = new DataTable();
                adapter.Fill(data);
                dgvEditUser.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.ToString());
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close(); // Ensure the connection is closed even if an exception occurs
                }
            }

        }

        private void loadCustomerAccounts()
        {
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("SELECT C_ID AS CustomerID," +
                                    "C_Username AS Username," +
                                    "C_Firstname AS Firstname," +
                                    "C_Lastname AS Lastname," +
                                    "C_Age AS Age," +
                                    "C_Email AS Email," +
                                    "C_Address AS Address," +
                                    "C_UserType AS Type " +
                                    "FROM CUSTOMERS", con);

                SqlDataAdapter adapter = new SqlDataAdapter(com);
                DataTable data = new DataTable();
                adapter.Fill(data);
                dgvEditUser.DataSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.ToString());
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close(); // Ensure the connection is closed even if an exception occurs
                }
            }

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.ShowDialog();
            this.Hide();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelProd.Visible = false;
            panelProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            lblAdmin.Visible = true;
            logoPic.Visible = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            sidebar.BringToFront();
            searchUsers.BringToFront();
            clearSBarUsers.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            
        }

        private void btnAccount_Click(object sender, EventArgs e)
        {

        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = false;
            panelView.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelProd.Enabled = true;
            panelProd.Visible = true;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelProd.BringToFront();
            sidebar.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            loadDataGridProducts();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = false;
            panelView.Enabled = false;
            panelProd.Enabled = false;
            panelProd.Visible = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = true;
            panelOrders.Visible = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelOrders.BringToFront();
            sidebar.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            loadDataGridOrders();
        }

        private void btnUsers_Click(object sender, EventArgs e)
        {
            lblAdmin.Visible = false;
            logoPic.Visible = false;
            panelView.Visible = true;
            panelView.Enabled = true;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelProd.Enabled = false;
            panelProd.Visible = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelView.BringToFront();
            sidebar.BringToFront();
            sidebarTimer.Start();
            if (sidebarExpand)
            {
                if (sidebar.Width == sidebar.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer.Stop();
                }
            }
            loadDataGridUsers();
            
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void closeAdd_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelView.Enabled = true;
            panelView.Visible = true;
            lblAdmin.Visible = true;
            logoPic.Visible = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (rbtnAdmin.Checked || rbtnCustomer.Checked)
            {
                string userType = rbtnAdmin.Checked ? "admin" : "customer";

                string firstname = txtBoxFName.Text;
                string lastname = txtBoxLname.Text;
                string age = txtBoxAge.Text;
                string email = txtBoxEmail.Text;
                string address = txtBoxAddress.Text;
                string username = txtBoxUName.Text;
                string password = txtBoxPassword.Text;
                string encryptedPassword = password;


                if (string.IsNullOrWhiteSpace(firstname))
                {
                    MessageBox.Show("Please enter a valid first name.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                if (string.IsNullOrWhiteSpace(lastname))
                {
                    MessageBox.Show("Please enter a valid last name.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                if (!int.TryParse(age, out int ageValue) || ageValue <= 0)
                {
                    MessageBox.Show("Please enter a valid age.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                if (!IsValidEmail(email))
                {
                    MessageBox.Show("Please enter a valid email address.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                if (string.IsNullOrWhiteSpace(address))
                {
                    MessageBox.Show("Please enter a valid address.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                if (string.IsNullOrWhiteSpace(username))
                {
                    MessageBox.Show("Please enter a valid username.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                if (string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Please enter a valid password.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                string insertQuery = "";
                if (userType == "admin")
                {
                    insertQuery = @"INSERT INTO ADMINISTRATOR (A_Firstname, A_Lastname, A_Age, A_Email, A_Address, A_UserType, A_Username, A_Password)
                    VALUES (@Firstname, @Lastname, @Age, @Email, @Address, @UserType, @Username, @Password)";
                }
                else
                {
                    string encryptedPwd = EncryptPassword(password);
                    insertQuery = @"INSERT INTO CUSTOMERS (C_Firstname, C_Lastname, C_Age, C_Email, C_Address, C_UserType, C_Username, C_Password)
                    VALUES (@Firstname, @Lastname, @Age, @Email, @Address, @UserType, @Username, @Password)";
                }

                using (SqlCommand cmd = new SqlCommand(insertQuery, con))
                {
                    cmd.Parameters.AddWithValue("@Firstname", firstname);
                    cmd.Parameters.AddWithValue("@Lastname", lastname);
                    cmd.Parameters.AddWithValue("@Age", ageValue); 
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Address", address);
                    cmd.Parameters.AddWithValue("@UserType", userType);
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", encryptedPassword); 

                    try
                    {
                        con.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show(userType + " added successfully.");
                            ClearInputFields();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add " + userType + ".");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
                loadDataGridUsers();
            }
            else
            {
                MessageBox.Show("Please select user type (admin or customer).", "User Type Not Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ClearInputFields()
        {
            txtBoxFName.Clear();
            txtBoxLname.Clear();
            txtBoxAge.Clear();
            txtBoxEmail.Clear();
            txtBoxAddress.Clear();
            rbtnAdmin.Checked = false;
            rbtnCustomer.Checked = false;
            txtBoxUName.Clear();
            txtBoxPassword.Clear();
        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(email, pattern);
        }

        private string EncryptPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private string DecryptPassword(string encryptedPassword)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(encryptedPassword));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            uploadPhoto.Filter = "Select image(*.JpG; *.png; *.Gif) | *.JpG; *.png; *.Gif";
            if(uploadPhoto.ShowDialog() == DialogResult.OK)
            {
                prodImage.Image = Image.FromFile(uploadPhoto.FileName);
                txtBoxImgPath.Text = uploadPhoto.FileName;
            }
        }

        private void closeProd_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelAddProd.Enabled = false;
            panelAddProd.Visible = false;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
        }

        


        private void btnAddProd_Click(object sender, EventArgs e)
        {
            MemoryStream memstr = new MemoryStream();
            prodImage.Image.Save(memstr, prodImage.Image.RawFormat);
            string PName = txtBoxPName.Text;
            string PDesc = txtBoxPDesc.Text;
            int PQuantity = int.Parse(txtBoxQuantity.Text); 
            double PPrice = double.Parse(txtBoxPrice.Text); 

            string insertQuery = @"INSERT INTO PRODUCTS (P_IMAGE, P_NAME, P_QUANTITY, P_PRICE, P_DESCRIPTION)
                           VALUES (@Image, @Name, @Quantity, @Price, @Description)";

            using (SqlCommand cmd = new SqlCommand(insertQuery, con))
            {
                cmd.Parameters.AddWithValue("@Image", memstr.ToArray());
                cmd.Parameters.AddWithValue("@Name", PName);
                cmd.Parameters.AddWithValue("@Quantity", PQuantity);
                cmd.Parameters.AddWithValue("@Price", PPrice);
                cmd.Parameters.AddWithValue("@Description", PDesc);

                try
                {
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Product added successfully.");
                        prodImage.Image = null;
                        txtBoxImgPath.Clear();
                        txtBoxImgPath.Clear();
                        txtBoxPName.Clear();
                        txtBoxPDesc.Clear();
                        txtBoxQuantity.Clear();
                        txtBoxPrice.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Failed to add product.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            loadDataGridProducts();
        }

        private void btnAddOrders_Click(object sender, EventArgs e)
        {

        }

        private void btnEditOrders_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteOrders_Click(object sender, EventArgs e)
        {

        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelAddProd.Visible = true;
            panelAddProd.Enabled = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelAddProd.BringToFront();

        }

        private void btnEditProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {

        }

        private void btnAddUsers_Click(object sender, EventArgs e)
        {
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelAddUsers.Visible = true;
            panelAddUsers.Enabled = true;
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelAddUsers.BringToFront();
            sidebar.BringToFront();
        }

        private void btnEditUsers_Click(object sender, EventArgs e)
        {
            panelAddProd.Visible = false;
            panelAddProd.Enabled = false;
            panelView.Enabled = false;
            panelView.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelOrders.Enabled = false;
            panelOrders.Visible = false;
            panelAddUsers.Visible = false;
            panelAddUsers.Enabled = false;
            panelEditUser.Visible = true;
            panelEditUser.Enabled = true;
            panelEditUser.BringToFront();
            sidebar.BringToFront();

        }

        

        private void btnDeleteUsers_Click(object sender, EventArgs e)
        {

        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            LoadAdminAccounts();
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            loadCustomerAccounts();
        }

        private void btnEditUser_Click(object sender, EventArgs e)
        {
            if (dgvEditUser.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvEditUser.SelectedRows[0];
                string userType = selectedRow.Cells["Type"].Value.ToString();

                if (userType == "admin")
                {
                    EditAdminAccount(selectedRow);
                }
                else if (userType == "customer")
                {
                    EditCustomerAccount(selectedRow);
                }
                else
                {
                    MessageBox.Show("Unknown user type.");
                    return;
                }

                // Don't populate text boxes here, as it might override user input

                string firstname = txtBoxEditFirstname.Text;
                string lastname = txtBoxEditLastname.Text;
                string email = txtBoxEditEmail.Text;
                string username = txtBoxEditUsername.Text;
                string age = txtBoxEditAge.Text;
                string address = txtBoxEditAddress.Text;

                // Validate fields
                if (!ValidateFields())
                {
                    return; // Exit if validation fails
                }

                using (SqlCommand cmd = new SqlCommand("", con))
                {
                    try
                    {
                        con.Open();
                        if (userType == "admin")
                        {
                            cmd.CommandText = @"UPDATE ADMINISTRATOR 
                                 SET A_FIRSTNAME = COALESCE(@Firstname, A_FIRSTNAME), 
                                     A_LASTNAME = COALESCE(@Lastname, A_LASTNAME), 
                                     A_EMAIL = COALESCE(@Email, A_EMAIL), 
                                     A_USERNAME = COALESCE(@Username, A_USERNAME),
                                     A_AGE = COALESCE(@Age, A_AGE), 
                                     A_ADDRESS = COALESCE(@Address, A_ADDRESS)
                                 WHERE A_ID = @AdminID";
                            cmd.Parameters.AddWithValue("@AdminID", selectedRow.Cells["AdminID"].Value);
                        }
                        else if (userType == "customer")
                        {
                            cmd.CommandText = @"UPDATE CUSTOMERS 
                                 SET C_FIRSTNAME = COALESCE(@Firstname, C_FIRSTNAME), 
                                     C_LASTNAME = COALESCE(@Lastname, C_LASTNAME), 
                                     C_EMAIL = COALESCE(@Email, C_EMAIL), 
                                     C_USERNAME = COALESCE(@Username, C_USERNAME),
                                     C_AGE = COALESCE(@Age, C_AGE), 
                                     C_ADDRESS = COALESCE(@Address, C_ADDRESS)
                                 WHERE C_ID = @CustomerID";
                            cmd.Parameters.AddWithValue("@CustomerID", selectedRow.Cells["CustomerID"].Value);
                        }

                        cmd.Parameters.AddWithValue("@Firstname", string.IsNullOrWhiteSpace(firstname) ? DBNull.Value : (object)firstname);
                        cmd.Parameters.AddWithValue("@Lastname", string.IsNullOrWhiteSpace(lastname) ? DBNull.Value : (object)lastname);
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrWhiteSpace(email) ? DBNull.Value : (object)email);
                        cmd.Parameters.AddWithValue("@Username", string.IsNullOrWhiteSpace(username) ? DBNull.Value : (object)username);
                        cmd.Parameters.AddWithValue("@Age", string.IsNullOrWhiteSpace(age) ? DBNull.Value : (object)age); // Assuming age is a string
                        cmd.Parameters.AddWithValue("@Address", string.IsNullOrWhiteSpace(address) ? DBNull.Value : (object)address);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User data updated successfully.");
                            ClearTextBoxes();

                            if (userType == "admin")
                            {
                                try
                                {
                                    
                                    SqlCommand com = new SqlCommand("SELECT A_ID AS AdminID," +
                                                                    "A_Username AS Username," +
                                                                    "A_Firstname AS Firstname," +
                                                                    "A_Lastname AS Lastname," +
                                                                    "A_Age AS Age," +
                                                                    "A_Email AS Email," +
                                                                    "A_Address AS Address," +
                                                                    "A_UserType AS Type " +
                                                                    "FROM ADMINISTRATOR", con);

                                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                                    DataTable data = new DataTable();
                                    adapter.Fill(data);
                                    dgvEditUser.DataSource = data;
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error: " + ex.ToString());
                                }
                                finally
                                {
                                    if (con.State == ConnectionState.Open)
                                    {
                                        con.Close(); // Ensure the connection is closed even if an exception occurs
                                    }
                                }
                            }
                            else if (userType == "customer")
                            {
                                try
                                {
                                    con.Open();
                                    SqlCommand com = new SqlCommand("SELECT C_ID AS CustomerID," +
                                                        "C_Username AS Username," +
                                                        "C_Firstname AS Firstname," +
                                                        "C_Lastname AS Lastname," +
                                                        "C_Age AS Age," +
                                                        "C_Email AS Email," +
                                                        "C_Address AS Address," +
                                                        "C_UserType AS Type " +
                                                        "FROM CUSTOMERS", con);

                                    SqlDataAdapter adapter = new SqlDataAdapter(com);
                                    DataTable data = new DataTable();
                                    adapter.Fill(data);
                                    dgvEditUser.DataSource = data;
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error: " + ex.ToString());
                                }
                                finally
                                {
                                    if (con.State == ConnectionState.Open)
                                    {
                                        con.Close(); // Ensure the connection is closed even if an exception occurs
                                    }
                                }
                            }

                            // Refresh DataGridView after successful edit
                            RefreshDataGridView();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update user data.");
                            ClearTextBoxes();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a user to edit.");
            }
        }

        private bool ValidateFields()
        {
            // Error handling for firstname, lastname, and address
            if (!string.IsNullOrWhiteSpace(txtBoxEditFirstname.Text) && !IsLettersOnly(txtBoxEditFirstname.Text))
            {
                MessageBox.Show("Firstname should contain only letters.");
                txtBoxEditFirstname.Text = "";
                return false;
            }
            if (!string.IsNullOrWhiteSpace(txtBoxEditLastname.Text) && !IsLettersOnly(txtBoxEditLastname.Text))
            {
                MessageBox.Show("Lastname should contain only letters.");
                txtBoxEditLastname.Text = "";
                return false;
            }
            if (!string.IsNullOrWhiteSpace(txtBoxEditAddress.Text) && !IsLettersOnly(txtBoxEditAddress.Text) && !IsNumeric(txtBoxEditAddress.Text))
            {
                MessageBox.Show("Address should contain only letters and digits.");
                txtBoxEditAddress.Text = "";
                return false;
            }
            // Error handling for age (numeric)
            if (!string.IsNullOrWhiteSpace(txtBoxEditAge.Text) && !IsNumeric(txtBoxEditAge.Text))
            {
                MessageBox.Show("Age should contain only numeric characters.");
                txtBoxEditAge.Text = "";
                return false;
            }

            // Validation passed
            return true;
        }



        private void RefreshDataGridView()
        {
            // Reload or refresh the data source and then rebind to DataGridView
            // Assuming LoadAdminAccounts() and loadCustomerAccounts() reload the data source
            // If not, replace with appropriate method to reload data
            LoadAdminAccounts(); // Reload admin data
            loadCustomerAccounts(); // Reload customer data
        }

        private void EditAdminAccount(DataGridViewRow selectedRow)
        {
            PopulateTextBoxes(selectedRow);
        }

        private void EditCustomerAccount(DataGridViewRow selectedRow)
        {
            PopulateTextBoxes(selectedRow);
        }

        private void PopulateTextBoxes(DataGridViewRow selectedRow)
        {

            // Only populate text boxes if they are empty
            if (string.IsNullOrWhiteSpace(txtBoxEditFirstname.Text))
            {
                txtBoxEditFirstname.Text = selectedRow.Cells["Firstname"].Value.ToString();
            }
            if (string.IsNullOrWhiteSpace(txtBoxEditLastname.Text))
            {
                txtBoxEditLastname.Text = selectedRow.Cells["Lastname"].Value.ToString();
            }
            if (string.IsNullOrWhiteSpace(txtBoxEditAge.Text))
            {
                txtBoxEditAge.Text = selectedRow.Cells["Age"].Value.ToString();
            }
            if (string.IsNullOrWhiteSpace(txtBoxEditEmail.Text))
            {
                txtBoxEditEmail.Text = selectedRow.Cells["Email"].Value.ToString();
            }
            if (string.IsNullOrWhiteSpace(txtBoxEditAddress.Text))
            {
                txtBoxEditAddress.Text = selectedRow.Cells["Address"].Value.ToString();
            }
            if (string.IsNullOrWhiteSpace(txtBoxEditUsername.Text))
            {
                txtBoxEditUsername.Text = selectedRow.Cells["Username"].Value.ToString();
            }
            
            
        }


        private bool IsLettersOnly(string text)
        {
            return text.All(char.IsLetter);
        }

        private bool IsNumeric(string text)
        {
            return text.All(char.IsDigit);
        }




        private void ClearTextBoxes()
        {
            txtBoxEditFirstname.Clear();
            txtBoxEditLastname.Clear();
            txtBoxEditAge.Clear();
            txtBoxEditEmail.Clear();
            txtBoxEditAddress.Clear();
            txtBoxEditUsername.Clear();
        }
        private void closeEditUser_Click(object sender, EventArgs e)
        {
            panelEditUser.Visible = false;
            panelEditUser.Enabled = false;
            panelView.Enabled = true;
            panelView.Visible = true;
        }

        private void dgvEditUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dgvEditUser.Rows[e.RowIndex];
                string userType = selectedRow.Cells["Type"].Value.ToString();

                if (userType == "admin")
                {
                    EditAdminAccount(selectedRow);
                }
                else if (userType == "customer")
                {
                    EditCustomerAccount(selectedRow);
                }
                PopulateTextBoxes(selectedRow);
            }
        }

        private void txtBoxSearchOrders_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = txtBoxSearchOrders.Text.Trim();

            // Construct the SQL query to retrieve records matching the search term
            SqlCommand com = new SqlCommand("", con);
            string query = "SELECT O_ID AS OrderId," +
                    "PRODUCT_ID AS ProductID," +
                    "PRODUCT_IMAGE AS ProductImage," +
                    "PRODUCT_NAME AS ProductName," +
                    "ORDERED_QUANTITY AS OrderedQuantity," +
                    "PRODUCT_PRICE AS ProductPrice," +
                    "ORDER_TOTAL_PRICE AS OrderTotalPrice," +
                    "ORDER_DATE AS OrderDate " +
                    "FROM ORDERS WHERE O_ID = @SearchTerm OR PRODUCT_NAME LIKE @ProductName";

            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@SearchTerm", searchTerm);
                    cmd.Parameters.AddWithValue("@ProductName", "%" + searchTerm + "%"); 

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvOrders.DataSource = dt;
                }
            }
        }

        private void clearSBarOrders_Click(object sender, EventArgs e)
        {
            txtBoxSearchOrders.Text = "";
        }

        private void txtBoxSearchProducts_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = txtBoxSearchOrders.Text.Trim();

            // Construct the SQL query to retrieve records matching the search term
            string query = "SELECT P_ID AS ProductID, " +
                                       "P_IMAGE AS ProductImage, " +
                                       "P_NAME AS ProductName, " +
                                       "P_QUANTITY AS ProductQuantity, " +
                                       "P_PRICE AS ProductPrice " +
                                 "FROM PRODUCTS WHERE P_NAME LIKE @ProductName";

            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@ProductName", "%" + searchTerm + "%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvProducts.DataSource = dt;
                }
            }
        }

        private void clearSBarProd_Click(object sender, EventArgs e)
        {
            txtBoxSearchProducts.Text = "";
        }

        private void txtBoxSearchUsers_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = txtBoxSearchUsers.Text.Trim();

            // Construct the SQL query to retrieve records matching the search term

            string query = "SELECT C_ID AS CustomerID, "+
                            "C_Username AS Username, " +
                            "C_Firstname AS Firstname, " +
                            "C_Lastname AS Lastname, " +
                            "C_Age AS Age, " +
                            "C_Email AS Email, " +
                            "C_Address AS Address, " +
                            "C_UserType AS Type  " +
                     "FROM CUSTOMERS WHERE C_Firstname LIKE @SearchTerm " + 
                     "OR C_Lastname LIKE @SearchTerm " +
                     "OR C_Username LIKE @SearchTerm " + 
                     "OR C_Email LIKE @SearchTerm ";

            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvView.DataSource = dt;
                }
            }
        }

        private void clearSBarUsers_Click(object sender, EventArgs e)
        {
            txtBoxSearchUsers.Text = "";
        }
    }
}
